<h3>Brown-Driver-Briggs' Hebrew Definitions, Thayer's Greek Definitions and Strong's Hebrew and Greek Dictionaries Combined</h3>
<h4>Enhanced with Tense, Voice &amp; Mood, plus AV Usage</h4>
<p>The correctly formatted Strong's, BDB and Thayer's Dictionaries; complete Authorized Version verses; and the Tense, Voice &amp; Mood are courtesy of Timothy S. Morton of <a href='http://www.bibleanalyzer.com/'>www.bibleanalyzer.com/</a>.</p>
<p>The BDB and Thayer's Dictionaries' numbered entries are reformatted as HTML numbered lists by the MySword Team for better rendering in MySword.</p>
<p>This new version of Strong's Dictionary for MySword initially released February 2012 shall replace the old version released last 2011 as there are some reported formatting issues especially with some BDB Definitions (e.g. H6213) and Authorized Version usages without commas; missing BDB definitions (e.g. H954) and missing Authorized Version verses (e.g. G1).</p>
<p><b>Brown-Driver-Brigg's Information</b></p>
<p>All of the original Hebrew and Aramaic words are arranged by the numbering system from Strong's Exhaustive Concordance of the Bible. In some cases more than one form of the word — such as the masculine and feminine forms of a noun — may be listed.
</p>
<p>Each entry is a Hebrew word, unless it is designated as Aramaic. Immediately after each word is given its equivalent in English letters, according to a system of transliteration. Then follows the phonetic. Next follows the Brown-Driver-Briggs' Definitions given in English.
</p>
<p>Then ensues a reference to the same word as found in Theological Wordbook of the Old Testament (TWOT), by R. Laird Harris, Gleason L. Archer, Jr., and Bruce K. Waltke. This section makes an association between the unique number used by TWOT with the Strong's number.
</p>
<p><b>Thayers Information</b></p>
<p>All of the original Greek words are arranged by the numbering system from Strong's Exhaustive Concordance of the Bible. The Strong's numbering system arranges most Greek words by their alphabetical order. This renders reference easy without recourse to the Greek characters. In some cases more than one form of the word - such as the masculine, feminine, and neuter forms of a noun - may be listed.
</p>
<p>Immediately after each word is given its exact equivalent in English letters, according to the system of transliteration laid down in the scheme here following. Then follows the phonetic. Next follows the Thayer's Definitions given in English.
</p>
<p>Then ensues a reference to the same word as found in the ten-volume Theological Dictionary of the New Testament (TDNT), edited by Gerhard Kittel. Both volume and page numbers cite where the word may be found.
</p>
<p>The presence of an asterisk indicates that the corresponding entry in the Theological Dictionary of the New Testament may appear in a different form than that displayed in Thayers' Greek Definitions.
</p>
<p><b>Strong's Hebrew and Greek Dictionaries Information</b></p>
<p>Dictionaries of Hebrew and Greek Words taken from Strong's Exhaustive
Concordance<br>
&nbsp;by James Strong, S.T.D., LL.D., 1890.</p>
<hr size=""2"" width=""80%"">
<h4 style=""text-align:center"">Strong's Hebrew and Greek Dictionaries<br/>
Enhanced with Tense, Voice &amp; Mood, plus AV Usage</h4>
<p style=""text-align:center"">Copyright 2011, Timothy S. Morton (www.BibleAnalyzer.com)<br>
All Rights Reserved </p>
<p>The original Strong Hebrew and Greek Dictionaries are in the public domain.
This greatly enhanced and expanded edition includes the Authorized
Version usage of each Hebrew/Greek word and is protected by a derivative
copyright to ensure its free and open distribution. Thus permission is granted by the copyright
holder to allow this text to be used under the following conditions:</p>
<ul>
<li><i>This text, including any additions or improvements that may be
made to the text, must be
distributed free of charge.</i></li>
<li><i> If this text is in any way encrypted or placed in a
proprietary
format, it must also be provided separately, with any additions
or improvements</i><i>, in an
open format, by the same party </i>(<i>by download is
sufficient</i>)</li>
<li><i> The text can be bundled with items that are sold (CD-Rom,
etc.)
on the condition it is freely offered separately, </i><i>with </i><i>any
additions or improvements, </i><i>by the same party, in an open format
</i>(<i>by download is
sufficient</i>)</li>
<li><i> This copyright notice must be included with all distributions.</i></li>
</ul>
<p>In essence, this license states the user can use this text in any way
they see fit as long as they freely provide the text, with any
additions and/or improvements, in an open and
easily accessible format (txt, SQLite, or any other readily accessible
format), and include this copyright notice with every distribution in any form. If
the user cannot abide by these terms, then no license is granted.</p>
<p>There is no warranty expressed or implied in regard to this text.</p>
<hr size=""2"" width=""80%"">
<p><b>Signs Employed</b></p>
+ (addition) denotes a rendering in the Authorized Version
of one or more Hebrew/Greek words in connection with the one under
consideration.
<br>
<br>
<b>x</b> (multiplication) denotes a rendering in the Authorized Version
that results from an idiom peculiar to the Hebrew/Greek.
<br>
<br>
<b>º</b> (degree), appended to a Hebrew word, denotes a vowel-pointing
corrected from that of the text. (This mark is set in Hebrew Bibles
over syllables in which the vowels of the margin have been inserted
instead of those properly belonging to the text.)
<br>
<br>
<b>( )</b> (parenthesis), in the renderings from the Authorized
Version, denotes a word or syllable sometimes given in connection with
the principal word to which it is annexed.
<br>
<br>
<b>[ ]</b> (bracket), in the rendering from the Authorized Version,
denotes the inclusion of an additional word in the Hebrew/Greek.
<br>
<br>
Italics, at the end of a rendering from the Authorized Version, denote
an explanation of the variations from the usual form.
<br>
<br>
",,1,2.0.10,"2021-08-06 00:00:00",,0,,,,"<p>version 2.0.10: Fixed H3787 typo proser->prosper; H5321 typo 5th->6th; G4376 truncated Thayer definition; G5050 wrong link to G5448, should be G5048</p>
<p>version 2.0.9: Fixed G2467 wrong link to G1942</p>
<p>version 2.0.8: Fixed H4633; Added entries for Hb, Hk, Hl, Hm</p>
<p>version 2.0.7: Fixed truncated G785 Thayer's definition</p>
<p>version 2.0.6: Fixed H6191, G2865, G3857</p><p>version 2.0.5: Fixed G970, G971, G1466, G2638, G3339, G5088, G5381, H136, H5284, H5307, H6316</p><p>version 2.0.4: Fixed some Hebrew/Aramaic Origin links in Thayer section from wrong G# to correct H#</p>
